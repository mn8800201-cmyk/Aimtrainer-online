# Aim Trainer - Score-only Leaderboard (Ready for GitHub Pages)

This package contains a mobile-friendly Aim Trainer that saves **scores only** to the browser's local storage.
It is safe to deploy on GitHub Pages. Leaderboard remains local to each user's browser (no server required).

## Files
- `index.html`  — Main game file (mobile-friendly)
- `style.css`   — Styling
- `README.md`   — This file

## Deploy to GitHub Pages (quick)
1. Create a new repository on GitHub (e.g., `aimtrainer-online`).
2. Upload these files to the repository root (index.html, style.css, README.md).
3. In repository Settings → Pages, select branch `main` (or `master`) and root `/` as the folder. Save.
4. After a minute, open `https://<your-username>.github.io/<repo-name>/` to access the game.
5. Note: Scores are stored locally in each browser's localStorage and will not be shared automatically.

## Optional: Share scores manually
- Use Export button in the leaderboard to download a JSON file of top scores and share it manually.

